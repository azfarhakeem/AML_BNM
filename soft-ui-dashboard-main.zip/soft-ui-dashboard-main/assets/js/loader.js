class Loader {
    constructor() {
        // Create the cover-spin container
        this.coverSpin = document.createElement("div");
        this.coverSpin.setAttribute("id", "cover-spin");

        // Create the second-wrapper div
        var secondWrapper = document.createElement("div");
        secondWrapper.classList.add("second-wrapper");

        // Create the circle-loader div
        var circleLoader = document.createElement("div");
        circleLoader.classList.add("circle-loader");

        // Create the circle divs
        var circleFour = document.createElement("div");
        circleFour.classList.add("circle", "circle_four");

        var circleThree = document.createElement("div");
        circleThree.classList.add("circle", "circle_three");

        var circleTwo = document.createElement("div");
        circleTwo.classList.add("circle", "circle_two");

        var circleOne = document.createElement("div");
        circleOne.classList.add("circle", "circle_one");

        // Append the circle divs to the circle-loader
        circleLoader.appendChild(circleFour);
        circleLoader.appendChild(circleThree);
        circleLoader.appendChild(circleTwo);
        circleLoader.appendChild(circleOne);

        // Append the circle-loader to the second-wrapper
        secondWrapper.appendChild(circleLoader);

        // Append the second-wrapper to the cover-spin container
        this.coverSpin.appendChild(secondWrapper);
        this.coverSpin.style.display = 'block';
        // Append the cover-spin container to the document body
        document.body.appendChild(this.coverSpin);

    }
    closeModal(){
        this.coverSpin.style.display = 'none';
    }
  
  }

  class ModalSupplierCustomerForm {
    constructor(source,destination,list) {
    this.source = this.capitalizeFirstLetter(source);
    this.destination = destination;
    this.list = this.capitalizeFirstLetter(list)
    this.modalId = "myModal";
    this.modalContentId = "modalContent";
    this.modal = null;
    this.modalContent = null;
    this.btn = null;
    this.span = null;
    }
  
    createModal() {
      // Create the modal container
      this.modal = document.createElement("div");
      this.modal.setAttribute("id", this.modalId);
      this.modal.classList.add("modal");
  
      this.modalContent = document.createElement("div");
      this.modalContent.setAttribute("id", this.modalContentId);
      this.modalContent.classList.add("modal-content");
      this.modalContent.innerHTML = `    <span class="close">&times;</span>
      <div class="container-fluid py-4">
        <div class="row">
          <div class="col-md-12">
            <div>
              <div class="card-header pb-0">
                <div class="d-flex align-items-center">
                  <p class="mb-0">Create STR Report</p>
                  <a class="btn btn-primary btn-sm ms-auto" href="file:///Users/nurhaqimkamaruddin/Downloads/soft-ui-dashboard-main/pages/billing.html">
                  Send</a>
                </div>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <div class="container-fluid py-4" id="tab1">
                        <div class="row">
                          <div class="col-md-12">
                              <div class="card-header pb-0">
                                <div class="d-flex align-items-center">
                                  <p class="mb-0">Fill In Information</p>
                                </div>
                              </div>
                              <div class="card-body">
                                <div class="row">
                                  <div class="col-md-6">
                                    <div class="form-group">
                                      <label for="example-text-input" class="form-control-label">Full Name</label>
                                      <input class="form-control" type="text" value="Azfar Hakeem">
                                    </div>
                                  </div>
                                  <div class="col-md-6">
                                    <div class="form-group">
                                      <label for="example-text-input" class="form-control-label">Email address</label>
                                      <input class="form-control" type="email" value="azfar@example.com">
                                    </div>
                                  </div>
                                  <div class="col-md-6">
                                    <div class="form-group">
                                      <label for="example-text-input" class="form-control-label">Account No.</label>
                                      <input class="form-control" type="text" value="21312213">
                                    </div>
                                  </div>
                                  <div class="col-md-6">
                                    <div class="form-group">
                                      <label for="example-text-input" class="form-control-label">Telephone No</label>
                                      <input class="form-control" type="text" value="601475449191">
                                    </div>
                                  </div>
                                </div>
                                <hr class="horizontal dark">
                                <p class="text-uppercase text-sm">Contact Information</p>
                                <div class="row">
                                  <div class="col-md-12">
                                    <div class="form-group">
                                      <label for="example-text-input" class="form-control-label">Address</label>
                                      <input class="form-control" type="text" value="Bld Mihail Kogalniceanu, nr. 8 Bl 1, Sc 1, Ap 09">
                                    </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="form-group">
                                      <label for="example-text-input" class="form-control-label">City</label>
                                      <input class="form-control" type="text" value="New York">
                                    </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="form-group">
                                      <label for="example-text-input" class="form-control-label">Country</label>
                                      <input class="form-control" type="text" value="United States">
                                    </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="form-group">
                                      <label for="example-text-input" class="form-control-label">Postal code</label>
                                      <input class="form-control" type="number" value="0">
                                    </div>
                                  </div>
                                </div>
                                <hr class="horizontal dark">
                                <p class="text-uppercase text-sm">Transaction Details</p>
                                <div class="row">
                                  <div class="col-md-12">
                                    <div class="form-group">
                                      <label for="example-text-input" class="form-control-label">Amount</label>
                                      <input class="form-control" type="text" value="2000000">
                                    </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="form-group">
                                      <label for="example-text-input" class="form-control-label">Scam/Trend</label>
                                      <input class="form-control" type="text" value="Durian Scam">
                                    </div>
                                  </div>
                                  <div class="col-md-4">
                                    <div class="form-group">
                                      <label for="example-text-input" class="form-control-label">PEP</label>
                                      <input class="form-control" type="text" value="True">
                                    </div>
                                  </div>
                                </div>
                              </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  
      // Append the modal content to the modal container
      this.modal.appendChild(this.modalContent);
  
      document.body.appendChild(this.modal);
    }
  
    initialize() {
      // Get the modal
      this.modal = document.getElementById(this.modalId);
      
      // Get the button that opens the modal
      this.btn = document.getElementById("generate");
  
      // Get the <span> element that closes the modal
      this.span = this.modal.getElementsByClassName("close")[0];
  
       // Check if the modal and span element exist
    if (this.modal && this.span) {
        // When the user clicks on the button, open the modal
        this.btn.onclick = () => {
          this.modal.style.display = "block";
        };
  
        // When the user clicks on <span> (x), close the modal
        this.span.onclick = () => {
          this.modal.style.display = "none";
        };
      } else {
        console.error("Modal or span element not found.");
      }
    // When the user clicks on the button, open the modal
    this.btn.onclick = () => {
      this.modal.style.display = "block";
    };

    // When the user clicks on <span> (x), close the modal
    this.span.onclick = () => {
      this.modal.style.display = "none";
    };

    }

      capitalizeFirstLetter(str) {
        if (typeof str !== 'string' || str.length === 0) {
          return str; // return original value if not a string or empty string
        }
      
        const words = str.split(' ');
        const capitalizedWords = words.map(word => {
          if (word.length > 0) {
            const firstChar = word.charAt(0).toUpperCase();
            const restChars = word.slice(1);
            return firstChar + restChars;
          }
          return word;
        });
        return capitalizedWords.join(' ');
      }
  }